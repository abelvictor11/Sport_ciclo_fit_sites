<?php 
defined( 'ABSPATH' ) || exit;
?>

<?php 
    $banner_promo = get_field('block_image_c');
    $banner_movil = get_field('banner_promo_movil');
    $banner_promo_link = get_field('link_image_c');
?>
<?php if($banner_promo):?>
    <div class="container mb-2 mt-4">
        <div class="row">
            <div class="col-12 p-0">
                <a href="<?php echo $banner_promo_link['url']; ?>">
                    <img loading="lazy" src="<?= $banner_promo['url'];?>" alt="<?= $banner_promo['title'];?>" class="banner-promo-desktop" width="100%" height="100%">
                    <img loading="lazy" src="<?= $banner_movil['url'] ?>" alt="<?= $banner_movil['title'] ?>" class="banner-promo-movil" width="100%" height="100%">
                </a>
            </div>
        </div>
    </div>
<?php endif; ?>
