<!-- DESTACADOS -->
<div id="destacados" class="container mb-5 mt-5 d-none">
	<div class="row">
		<div class="col-md-12">
			<h2>Nuestros destacados</h2>
		</div>
		<div class="col-md-12 mt-4">
			<?php echo do_shortcode( '[products limit="24" columns="4" visibility="featured" ]' ); ?>
		</div>
	</div>	
</div>
<!-- END DESTACADOS -->