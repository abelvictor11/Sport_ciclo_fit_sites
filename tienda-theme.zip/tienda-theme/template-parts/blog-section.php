<div id="blog" class="container mb-5">
	<div class="row">
		<div class="col-md-12">
			<h2>BLOG</h2>
		</div>
		<div class="container-fluid mb-3">
			<div class="row">
				<?php echo do_shortcode( '[lastest-post]' ); ?>
				<div class="col-md-12 mt-3">
					<a href="/blog" class="btn cta-blog">VER TODAS LAS PUBLICACIONES</a>
				</div>
			</div>
		</div>
	</div>
</div>