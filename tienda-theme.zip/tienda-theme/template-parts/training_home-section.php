<!-- ENTRENA EN CASA -->
<div id="entrena-en-casa" class="container-fluid mb-5 mt-5">
	<div class="row">
		<div class="col-md-12 mb-5">
			<h2 class="text-center block-title">Disponibles Cuarentena</h2>
			<div class="border blue"></div>
		</div>
		<div class="col-md-12 mt-4">
			<?php echo do_shortcode( '[products limit="4" columns="4" category="entrenaencasa" orderby="rand"]' ); ?>
		</div>
		<div class="col-md-12 mt-1 mb-5">
			<a href="https://tienda-sportfitness.com/categoria/entrenaencasa?utm_source=read_more_click" class="btn cta-blog" style="background: #3a9fdf; color: white; font-size: 25px; padding: 14px; height: 60px; width: 300px; border-color: black; border: solid 2px black;">VER TOD0</a>
		</div>
	</div>	
</div>
<!-- END ENTRENA EN CASA -->