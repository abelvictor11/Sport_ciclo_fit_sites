<?php
// Exit if accessed directly.
defined('ABSPATH') || exit;
$reassurances = get_field('reassurance');
?>
<!-- START BANNER -->
<div id="reassurance-container" class="container mb-4">
    <div class="desktop">
        <div class="row">
            <?php if($reassurances): foreach($reassurances as $reassurance): ?>
                <div class="col-4">
                    <div class="content-card-reassurance">
                        <div class="content-left">
                            <img src="<?= $reassurance['logo']['url'] ?>" alt="icono">
                        </div>
                        <div class="content-right">
                            <?= $reassurance['text']; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
    <div class="movil">
        <div class="owl-carousel reassurance owl-theme">
            <?php if($reassurances): foreach($reassurances as $reassurance): ?>
                <div class="item">
                    <div class="content-card-reassurance">
                        <div class="content-left">
                            <img src="<?= $reassurance['logo']['url'] ?>" alt="icono">
                        </div>
                        <div class="content-right">
                            <?= $reassurance['text']; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
</div>
<!-- END BANNER -->