<?php
defined('ABSPATH') || exit;
?>

<?php if (have_rows('our_brands')) : ?>
    <div id="brands" class="container mt-2">
        <div class="row">
            <div class="col-12">
                <?php if (is_front_page() == true) : ?>
                    <h2 class="title-marcas">Las mejores marcas</h2>
                <?php else : ?>
                    <h1 class="title-marcas">Marcas</h1>
                <?php endif; ?>
            </div>
            <div class="owl-carousel brands owl-theme">
                <?php
                    $brands = get_field('our_brands');
                    if($brands):
                        foreach($brands as $brand):
                        $brand_content = $brand['brand'];
                ?>
                <div class="item">
                    <div class="content">
                        <div class="desktop">
                            <div class="header-brands">
                                <div class="banner">
                                    <img src="<?=  $brand_content['brand_banner']['url'] ?>" alt="<?=  $brand_content['brand_banner']['title'] ?>" class="image-banner-brands" width="100%" height="100%">
                                    <div class="content-logo-brands">
                                        <img src="<?= $brand_content['brand_logo']['url'] ?>" alt="<?= $brand_content['brand_logo']['title'] ?>" class="logo" width="5rem" height="5rem">
                                    </div>
                                </div>
                            </div>
                            <div class="body-brands">
                                <h3 class="title-brands"><?= $brand_content['nombre'] ?></h3>
                                <div class="row">
                                    <?php if($brand_content['products']): foreach($brand_content['products'] as $product): ?>
                                        <div class="col-4 p-2">
                                            <div class="content-image-product-brands">
                                                <a href="<?= $product['product_link'] ?>">
                                                    <img src="<?= $product['product_image']['url'] ?>" class="image-products-brands" alt="<?= $product['product_image']['title'] ?>" width="100%" height="100%">
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; endif; ?>
                                </div>
                                <div class="link-brands">
                                    <a href="<?= $brand_content['brand_link'] ?>">Ver marca</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
                        endforeach;
                    endif;
                ?>
            </div>
            <?php if (is_front_page() == true) : ?>
                <div class="col-12">
                    <a href="<?= home_url(); ?>/marcas" class="sportfitness"><strong>Ver todas las marcas</strong><span><i class="fa fa-chevron-right" aria-hidden="true"></i></span></a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>