<?php 
defined( 'ABSPATH' ) || exit;
$best_selling = get_field('best_selling_categories');
?>
<?php if( have_rows('best_selling_categories') ): ?>
    <div id="best-sellers-categories" class="container">
        <div class="row mt-4 content-category-best-selling">
            
            <?php while( have_rows('best_selling_categories') ): the_row();

                // Get sub field values.
                $title = get_sub_field('title');
                $text = get_sub_field('text');
                $products = get_sub_field('products');
                
                $offers_products = [];
                ?>
                <div class="col-md-12">
                    <div class="title-link">
                        <h3 class="title-best-selling"><?= $title; ?></h3>
                        <a href="<?= $best_selling['show_more_link']; ?>" class="show-more-best-selling"><span>Ver más</span> <span><i class="fa fa-chevron-right" aria-hidden="true"></i></span></a>
                    </div>
                    
                    <?php 
                        
                    if (is_array($products) || is_object($products)){
                        foreach($products as $products){
                            $product_id = $products['product'];
                            array_push($offers_products, $product_id);
                            
                        }
                    }
                    $offers_products_list = implode(',', $offers_products);
                    echo do_shortcode("[products ids='.$offers_products_list.']");
                    
                    ?>
                </div>
                
            <?php endwhile; ?>
            
        </div>
    </div>
<?php endif; ?>
<!-- <div class="movil-category-best-selling">
    <?php $best_selling = get_field('best_selling_categories'); ?>
    <div class="container">
        <div class="row mt-4 content-movil">
            <div class="col-12">
                <h3 class="title-best-selling"><?= $best_selling['title']; ?></h3>
            </div>
            <?php if($best_selling['productos_movil']): foreach($best_selling['productos_movil'] as $item): $product = $item['product']; ?>
                <div class="col-6 p-0">
                    <?= do_shortcode('[products ids='.$product.']'); ?>
                </div>
            <?php endforeach; endif; ?>
            <div class="col-12 mt-2">
                <a href="<?= $best_selling['show_more_link'] ?>" class="show-more-best-selling"><span>Ver más</span> <span><i class="fa fa-chevron-right" aria-hidden="true"></i></span></a>
            </div>
        </div>
    </div> 
</div> -->